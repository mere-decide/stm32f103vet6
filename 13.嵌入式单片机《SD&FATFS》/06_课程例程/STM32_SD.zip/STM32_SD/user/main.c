#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "stdio.h"
#include "w25q64.h"
#include "mmc_sd.h"

int main(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	USART_Config();
	printf("�������\r\n");
	printf("www.jcznedu.com\r\n");
	printf("���ڳ�ʼ���ɹ�\r\n");
	sFLASH_Init();
	printf("Flash ID is %#0x\r\n",sFLASH_ReadID());
	uint8_t SD_ReadBuf[64] = "\0";
	if(SD_Config() == 0)
	{
		printf("SD Config OK\r\n");
//		SD_WriteDisk("www.jcznedu.com",0X00,1);
		SD_ReadDisk(SD_ReadBuf,0X00,1);
		printf("SD_ReadBuf:%s\r\n",SD_ReadBuf);
	}
	
	while(1)
	{		
		
	}
}





