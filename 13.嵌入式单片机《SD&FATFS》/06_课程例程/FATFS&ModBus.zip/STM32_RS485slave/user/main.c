#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "stdio.h"
#include "RS485.h"
#include "modbus.h"
#include "gpio.h"
#include "dma.h"
#include "sht20.h"

#include "freertos.h"
#include "task.h"

/*
	reg1		����ADֵ
	reg2		����������ADֵ
	reg3		�¶�*10
	reg4		ʪ��*10
	reg5		byte0~byte4:LED1 LED2 LED3 LED4 BEEP state
	reg6		byte0~byte2:KEY1 KEY2 KEY3 state
*/
uint16_t ModBusBuf[6];

TaskHandle_t TaskHandle_Start = NULL;
TaskHandle_t TaskHandle_LED = NULL;
TaskHandle_t TaskHandle_Key = NULL;
TaskHandle_t TaskHandle_SHT20 = NULL;
TaskHandle_t TaskHandle_ModBus = NULL;

void Task_Start(void *p);
void Task_LED(void *p);
void Task_Key(void *p);
void Task_SHT20(void *p);
void Task_Modbus(void *p);

BaseType_t TaskRet = 0;

int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	USART_Config();
	RS485_Config(9600);
	ModBus_TIMConfig();
	LED_Config();
	BEEP_Config();
	Key_Config();
	DMA_Config();
	SHT20_Config();
	
#if debug==1
	printf("�������\r\n");
	printf("www.jcznedu.com\r\n");
	printf("���ڳ�ʼ���ɹ�\r\n");
#endif
	//RS485_SendBuf("JCZN RS485",sizeof("JCZN RS485"));
	
	TaskRet = xTaskCreate(
			Task_Start,
			"start",
			128,
			(void *)&TaskHandle_Start,
			1,
			&TaskHandle_Start
	);
	if(TaskRet == pdPASS)
		printf("���񴴽��ɹ�\r\n");

	vTaskStartScheduler();
	
	while(1)
	{		
		ModBus_GetData();
	}
}

TaskStatus_t test1;
eTaskState state;
void Task_Start(void *p)
{
	//�����ٽ籣��
	taskENTER_CRITICAL();
	
	//����ϵͳҪʹ�õ�����
	xTaskCreate(Task_LED,"Led1",64,NULL,3,&TaskHandle_LED);
	xTaskCreate(Task_Key,"key",64,NULL,6,&TaskHandle_Key);
	xTaskCreate(Task_SHT20,"Tem_Hum",128,NULL,3,&TaskHandle_SHT20);
	xTaskCreate(Task_Modbus,"ModBus",256,NULL,6,&TaskHandle_ModBus);
	
	//�������-ɾ���Լ�
	vTaskDelete(*((TaskHandle_t *)p));	
	//�˳��ٽ籣��
	taskEXIT_CRITICAL();
}

void Task_LED(void *p)
{
	while(1)
	{
		LED1_TOGGLE;
		LED2_TOGGLE;
		LED3_TOGGLE;
		LED4_TOGGLE;
		BEEP_TOGGLE;
		vTaskDelay(1500);
	}
}

void Task_Key(void *p)
{
	while(1)
	{
		if(Input_Key1State())
		{
			printf("Key1 down\r\n");
		}
		if(Input_Key2State())
		{
			printf("Key2 down\r\n");
		}
		if(Input_Key3State())
		{
			printf("Key3 down\r\n");
		}
		vTaskDelay(5);
	}
}

void Task_SHT20(void *p)
{
	_SHT20Data data = {0};
	while(1)
	{
		SHT20_GetData(&data);
		//printf("tem %.1f\r\n",data.Tem);
		//printf("hum %.1f\r\n",data.Hum);
		ModBusBuf[2] = (uint16_t)(data.Tem*10);
		ModBusBuf[3] = (uint16_t)(data.Hum*10);
		
//		printf("%d ",ModBusBuf[0]);
//		printf("%d ",ModBusBuf[1]);
//		printf("%d ",ModBusBuf[2]);
//		printf("%d ",ModBusBuf[3]);
//		printf("%x ",ModBusBuf[4]);
//		printf("%x\r\n",ModBusBuf[5]);
		vTaskDelay(2000);
	}
}

void Task_Modbus(void *p)
{
	while(1)
	{
		ModBus_GetData();
		vTaskDelay(10);
	}
}
