#ifndef _ADC_H_
#define _ADC_H_

#include "stm32f10x.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"


void ADC1_Config(void);
uint16_t ADC1_GetR(void);
void ADC2_Config(void);
uint16_t ADC2_GetADCval(void);

#endif
