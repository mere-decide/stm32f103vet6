#ifndef _MODBUS_H_
#define _MODBUS_H_

#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "RS485.h"

void ModBus_TIMConfig(void);
void ModBus_GetData(void);

#endif

