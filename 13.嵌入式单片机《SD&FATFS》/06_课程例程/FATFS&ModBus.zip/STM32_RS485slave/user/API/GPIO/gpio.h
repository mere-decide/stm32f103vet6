#ifndef _GPIO_H_
#define _GPIO_H_

#include "stm32f10x.h"
#include "delay.h"

typedef enum{
	BEEP_CLOSE=0,
	BEEP_OPEN
}_BeepCtrl;

extern uint16_t ModBusBuf[6];

#define BEEP_CTRL(x) (x)?(ModBusBuf[4] |= (1 << 4),GPIOC->ODR |= (1 << 8)):(ModBusBuf[4] &= ~(1 << 4),GPIOC->ODR &= ~(1 << 8))
#define BEEP_TOGGLE (ModBusBuf[4] ^= (1 << 4),GPIOC->ODR ^= (1 << 8))

#define LED1_CTRL(x) (x)?(ModBusBuf[4] |= (1 << 0),GPIOB->ODR &= ~(1 << 8)):(ModBusBuf[4] &= ~(1 << 0),GPIOB->ODR |= (1 << 8))
#define LED2_CTRL(x) (x)?(ModBusBuf[4] |= (1 << 1),GPIOB->ODR &= ~(1 << 9)):(ModBusBuf[4] &= ~(1 << 1),GPIOB->ODR |= (1 << 9))
#define LED3_CTRL(x) (x)?(ModBusBuf[4] |= (1 << 2),GPIOE->ODR &= ~(1 << 0)):(ModBusBuf[4] &= ~(1 << 2),GPIOE->ODR |= (1 << 0))
#define LED4_CTRL(x) (x)?(ModBusBuf[4] |= (1 << 3),GPIOE->ODR &= ~(1 << 1)):(ModBusBuf[4] &= ~(1 << 3),GPIOE->ODR |= (1 << 1))
#define LED1_TOGGLE (ModBusBuf[4] ^= (1 << 0),GPIOB->ODR ^= (1 << 8))
#define LED2_TOGGLE (ModBusBuf[4] ^= (1 << 1),GPIOB->ODR ^= (1 << 9))
#define LED3_TOGGLE (ModBusBuf[4] ^= (1 << 2),GPIOE->ODR ^= (1 << 0))
#define LED4_TOGGLE (ModBusBuf[4] ^= (1 << 3),GPIOE->ODR ^= (1 << 1))

#define MotorA_CTRL(x) (x)?(GPIOC->ODR |= (1 << 9)):(GPIOC->ODR &= ~(1 << 9))
#define MotorB_CTRL(x) (x)?(GPIOC->ODR |= (1 << 7)):(GPIOC->ODR &= ~(1 << 7))

typedef enum{
	False=0,
	Ture
}_bool;

typedef enum{
	STATE_NO=0,	//δ����״̬
	STATE_DOWN,	//����״̬
	STATE_UP		//����״̬
}_KeyState;

#define KEY1_Get !!(GPIOA->IDR & (1 << 0))
#define KEY2_Get !!(GPIOC->IDR & (1 << 3))
#define KEY3_Get !!(GPIOC->IDR & (1 << 2))

void BEEP_Config(void);
void LED_Config(void);
void Motor_Config(void);
void Key_Config(void);
uint8_t Key_GetVal(void);
uint8_t Input_Key1State(void);
uint8_t Input_Key2State(void);
uint8_t Input_Key3State(void);

#endif
