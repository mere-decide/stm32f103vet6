#ifndef _BASICTIM_H_
#define _BASICTIM_H_

#include "stm32f10x.h"

extern uint32_t KeyDownTimerMs;

void TIM6_Config(void);

#endif


