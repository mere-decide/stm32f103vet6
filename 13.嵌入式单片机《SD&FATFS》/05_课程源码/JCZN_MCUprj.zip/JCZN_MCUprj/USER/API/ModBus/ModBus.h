#ifndef _MODBUS_H_
#define _MODBUS_H_

#include "stm32f10x.h"
#include "RS485.h"

void ModBus_Config(uint32_t brr);
uint32_t ModBus_CRC16(uint8_t *data, uint16_t length);
void ModBus_Send03Cmd(uint8_t SlaveID,uint16_t StartAddr,uint16_t RegCount);

#endif


