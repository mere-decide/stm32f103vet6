#ifndef _SPI_W25Q64_H_
#define _SPI_W25Q64_H_

#include "stm32f10x.h"

#define SPIW25Q64_ClockPORTCmd RCC_APB2PeriphClockCmd
#define SPIW25Q64_CmdPORT RCC_APB2Periph_GPIOB
#define SPIW25Q64_ClockSPICmd RCC_APB1PeriphClockCmd
#define SPIW25Q64_CmdSPIx RCC_APB1Periph_SPI3

//SPI_MOSI	PB15	SPI2_MOSI	�����������	
//SPI_MISO	PB14	SPI2_MISO	��������
//SPI_SCK		PB13	SPI2_SCLK	�����������
//FLASH_CS	PB12	SPI2_NSS	ͨ���������
#define MOSI_PORT GPIOB
#define MOSI_PIN	GPIO_Pin_5
#define MISO_PORT GPIOB
#define MISO_PIN	GPIO_Pin_4
#define SCLK_PORT GPIOB
#define SCLK_PIN	GPIO_Pin_3
#define CS_PORT GPIOB
#define CS_PIN	GPIO_Pin_6

#define W25Q64_SPIx	SPI3

#define W25Q64_CS(x) ((x)?(GPIO_SetBits(CS_PORT,CS_PIN)):(GPIO_ResetBits(CS_PORT,CS_PIN)))

void Flash_SPIConfig(void);
uint16_t Flash_SPIWR_data(uint16_t Data);

#endif
