#ifndef _DELAY_H_
#define _DELAY_H_

#include "stm32f10x.h"

#define Delay_Nopnms(x) Delay_Nopnus(x*1000)

extern uint32_t LEDRun[2];
extern uint32_t ADCRun[2];

void Delay_Nop1us(void);
void Delay_Nopnus(uint32_t time);

#endif


