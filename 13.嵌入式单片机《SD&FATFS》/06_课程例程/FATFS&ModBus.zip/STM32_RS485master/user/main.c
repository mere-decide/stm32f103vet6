#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "stdio.h"
#include "RS485.h"
#include "modbus.h"
#include "tft_lcd.h"
#include "w25q64.h"
#include "mmc_sd.h"
#include "ff.h"

FATFS fs;
FIL fp_0disk;
UINT Retbw = 0;
char bufslave[128] = "\0";
int main(void)
{
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	USART_Config();
	SysTick_Config(72000);
	RS485_Config(9600);
	ModBus_TIMConfig();
	LCD_Config();
	sFLASH_Init();
	if(SD_Config() == 0)
	{
		printf("SD Config OK\r\n");
		if(f_mount(&fs, "0:", 0) == FR_OK)
		{
			printf("FATFS Mount OK\r\n");
			if(f_open(&fp_0disk,"0:Slave.csv",FA_OPEN_ALWAYS|FA_READ|FA_WRITE) == FR_OK)
			{
				printf("File Open OK\r\n");
				
				f_write(&fp_0disk,",,,,,,�������,www.jcznedu.com,�й������ϡ�֣��,\r\n",sizeof(",,,,,,�������,www.jcznedu.com,�й������ϡ�֣��,\r\n"),&Retbw);
				printf("Retbw=%d\r\n",Retbw);
				f_write(&fp_0disk,"�¶�,ʪ��,����,��ֵ,����,����,�Ƕ�,LED1,LED2,LED3,LED4,������,KEY1,KEY2,KEY3\r\n",sizeof("�¶�,ʪ��,����,��ֵ,����,����,�Ƕ�,LED1,LED2,LED3,LED4,������,KEY1,KEY2,KEY3\r\n"),&Retbw);
				printf("Retbw=%d\r\n",Retbw);
				
				f_close(&fp_0disk);
			}
		}
	}
	
	printf("�������\r\n");
	printf("www.jcznedu.com\r\n");
	printf("���ڳ�ʼ���ɹ�\r\n");
	LCD_DrawString(24,0,BLUE,WHITE,Fontsize_24,"֣�ݽ�����ܼ���");
	LCD_DrawString(72,24,BLUE,WHITE,Fontsize_24,"���޹�˾");
	LCD_DrawString(60,48,BLUE,WHITE,Fontsize_16,"www.jcznedu.com");
		
	uint32_t Flag = 0;
	while(1)
	{		
		ModBus_GetData();
		if(ModbusSend[0] >= ModbusSend[1])
		{
			switch(Flag)
			{
				case 0:ModBus_Send03Command(0X01,0,1);Flag+=1;break;
				case 1:ModBus_Send03Command(0X02,0,2);Flag+=1;break;
				case 2:ModBus_Send03Command(0X03,0,6);Flag=0;break;
			}
			ModbusSend[0] = 0;
		}
		if(FatfsRun[0] >= FatfsRun[1])
		{
			if(f_open(&fp_0disk,"0:Slave.csv",FA_READ|FA_WRITE) == FR_OK)
			{
				
				f_lseek(&fp_0disk,f_size(&fp_0disk)+1);

//�¶�,ʪ��,����,��ֵ,����,����,�Ƕ�,LED1,LED2,LED3,LED4,������,KEY1,KEY2,KEY3\r\n
				sprintf(bufslave,"%4.1f,%4.1f,%4d,%4d,%6.1f,%s,%4d,%s,%s,%s,%s,%s,%s,%s,%s\r\n",
					SlaveData.tem,
					SlaveData.hum,
					SlaveData.light,
					SlaveData.R,
					SlaveData.WindSpeed,
					WindBuf[SlaveData.WindDir],
					SlaveData.WindAngle,
					StateBuf[SlaveData.LED1],
					StateBuf[SlaveData.LED2],
					StateBuf[SlaveData.LED3],
					StateBuf[SlaveData.LED4],
					StateBuf[SlaveData.BEEP],
					StateBuf[SlaveData.KEY1+2],
					StateBuf[SlaveData.KEY2+2],
					StateBuf[SlaveData.KEY3+2]);
				f_write(&fp_0disk,bufslave,strlen(bufslave),&Retbw);
				
				f_close(&fp_0disk);
			}
			
			FatfsRun[0] = 0;
		}
	}
}





