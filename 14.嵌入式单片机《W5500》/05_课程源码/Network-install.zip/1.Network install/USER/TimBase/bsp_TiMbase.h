#ifndef TIME_TEST_H
#define TIME_TEST_H

#include "HAL_device.h"

void TIM2_NVIC_Configuration(void);
void TIM2_Configuration(void);

#endif	/* TIME_TEST_H */
