#ifndef _USART_H_
#define _USART_H_

#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"


typedef struct{
	uint8_t data[128];
	uint16_t count;
}_USART_Get;

void USART1_Config(uint32_t brr);
void USART1_SendData(uint8_t *data,uint32_t len);

#endif
