#ifndef _MODBUS_H_
#define _MODBUS_H_

#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"
#include "RS485.h"

typedef struct{
	float tem;
	float hum;
	uint32_t light;
	uint32_t R;
	uint8_t LED1;
	uint8_t LED2;
	uint8_t LED3;
	uint8_t LED4;
	uint8_t BEEP;
	uint8_t KEY1;
	uint8_t KEY2;
	uint8_t KEY3;
	float WindSpeed;
	uint16_t WindDir;
	uint16_t WindAngle;
}_SlaveStr;
extern _SlaveStr SlaveData;
extern char *WindBuf[8];
extern char *StateBuf[4];

void ModBus_TIMConfig(void);
void ModBus_Send03Command(uint8_t DeviceAddr,uint16_t addr,uint16_t number);
void ModBus_GetData(void);

#endif

