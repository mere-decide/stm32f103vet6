#ifndef _DMA_H_
#define _DMA_H_

#include "stm32f10x.h"

extern uint16_t DMA_GetData[2];

void DMA1_Config(void);

#endif

