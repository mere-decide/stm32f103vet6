#ifndef _RS485_H_
#define _RS485_H_

#include "stm32f10x.h"
#include "stdio.h"
#include "string.h"

typedef enum{
	Mode_Recv=0,
	Mode_Send
}_485mode;

typedef struct{
	uint8_t buf[128];
	uint16_t count;
	uint8_t flag;
}_RS485Data;
extern _RS485Data RS485RecvData;

#define RS485_Mode(x) (x)?(GPIO_SetBits(GPIOA,GPIO_Pin_12)):(GPIO_ResetBits(GPIOA,GPIO_Pin_12))

void RS485_Config(uint32_t brr);
void RS485_SendBuf(uint8_t *byte,uint32_t len);

#endif

