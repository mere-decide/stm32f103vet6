#ifndef _SHT20_H_
#define _SHT20_H_

#include "stm32f10x.h"
#include "delay.h"

#define SHT20OUT_SCL(x)  (x)?(GPIOB->ODR |= (1 << 10)):(GPIOB->ODR &= ~(1 << 10))
#define SHT20OUT_SDA(x)  (x)?(GPIOB->ODR |= (1 << 11)):(GPIOB->ODR &= ~(1 << 11))
#define SHT20IN_SDA   !!(GPIOB->IDR & (1 << 11))  //����SDA 

#define SHT20SDA_IN		{GPIOB->CRH &= ~(0XF << 12);GPIOB->CRH |= (0X4 << 12);}
#define SHT20SDA_OUT 	{GPIOB->CRH &= ~(0XF << 12);GPIOB->CRH |= (0X3 << 12);}

#define SHT20_Adder 0x80 	//SHT20������ַ
#define CMD_Write  	0xE6 	//д����
#define CMD_Read   	0xE7 	//������
#define CMD_GetTem 	0xF3	//�����¶�����
#define CMD_GetHum 	0xF5  //�������ʪ������

typedef enum{
	IIC_ACK=0,
	IIC_NACK
}_IICack;

typedef struct{
	float Tem;
	float Hum;
}_SHT20Data;

void SHT20_Config(void);
void SHT20_GetData(_SHT20Data *data);

#endif

