#ifndef _KEY_H_
#define _KEY_H_

#include "stm32f10x.h"
#include "delay.h"

#define KEY1_State !!(GPIOA->IDR & (1 << 0))
#define KEY2_State !!(GPIOC->IDR & (1 << 3))
#define KEY3_State !!(GPIOC->IDR & (1 << 2))

void KEY_Config(void);
uint8_t Key_GetVal(void);

#endif
