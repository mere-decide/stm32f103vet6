#include "delay.h"

uint32_t ModbusSend[2] = {0,2000};
uint32_t FatfsRun[2] = {0,30000};

void SysTick_Handler(void)
{
	ModbusSend[0]++;
	FatfsRun[0]++;
}

/******************************
�������ƣ�Delay_Nus
�������ܣ�NOP��ʱ1us
������ڣ���
�������ڣ���
�������ߣ�
******************************/
void Delay_Nopnus(uint32_t timer)
{
	while(timer--)
	{
		__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
		__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
		__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
		__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
		__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
		__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
		__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();__nop();
		__nop();__nop();
	}
}

