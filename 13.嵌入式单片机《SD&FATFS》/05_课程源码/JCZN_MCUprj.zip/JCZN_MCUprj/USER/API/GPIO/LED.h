#ifndef _LED_H_
#define _LED_H_

#include "stm32f10x.h"

//#define LED1_Ctrl(x) (x)?(GPIOB->ODR &= ~(1 << 8)):(GPIOB->ODR |= (1 << 8))
//#define LED2_Ctrl(x) (x)?(GPIOB->ODR &= ~(1 << 9)):(GPIOB->ODR |= (1 << 9))
#define LED1_Ctrl(x) (x)?(TIM4->CCR3 = 999):(TIM4->CCR3 = 0)
#define LED2_Ctrl(x) (x)?(TIM4->CCR4 = 999):(TIM4->CCR4 = 0)
#define LED3_Ctrl(x) (x)?(GPIOE->ODR &= ~(1 << 0)):(GPIOE->ODR |= (1 << 0))
#define LED4_Ctrl(x) (x)?(GPIOE->ODR &= ~(1 << 1)):(GPIOE->ODR |= (1 << 1))

#define LED1_TOGGLE (GPIOB->ODR ^= (1 << 8))
#define LED2_TOGGLE (GPIOB->ODR ^= (1 << 9))
#define LED3_TOGGLE (GPIOE->ODR ^= (1 << 0))
#define LED4_TOGGLE (GPIOE->ODR ^= (1 << 1))

void LED_Config(void);

#endif
