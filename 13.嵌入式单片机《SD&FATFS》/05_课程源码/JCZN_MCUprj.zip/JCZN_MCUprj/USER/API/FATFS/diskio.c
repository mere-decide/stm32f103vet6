/*-----------------------------------------------------------------------*/
/* Low level disk I/O module skeleton for FatFs     (C)ChaN, 2016        */
/*-----------------------------------------------------------------------*/
/* If a working storage control module is available, it should be        */
/* attached to the FatFs via a glue function rather than modifying it.   */
/* This is an example of glue functions to attach various exsisting      */
/* storage control modules to the FatFs module with a defined API.       */
/*-----------------------------------------------------------------------*/

#include "ff.h"			/* Obtains integer types */
#include "diskio.h"		/* Declarations of disk functions */
#include "mmc_sd.h"
#include "stdio.h"
#include "stdlib.h"
/* Definitions of physical drive number for each drive */
#define SD_TF		0	


/*-----------------------------------------------------------------------*/
/* Get Drive Status                                                      */
/*-----------------------------------------------------------------------*/
DSTATUS disk_status (
	BYTE pdrv		/* Physical drive nmuber to identify the drive */
)
{

	switch (pdrv) {
	case SD_TF :
		return RES_OK;
	}
	return STA_NOINIT;
}



/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS disk_initialize (
	BYTE pdrv				/* Physical drive nmuber to identify the drive */
)
{

	switch (pdrv) {
	case SD_TF :
		return SD_Config();
	}
	return STA_NOINIT;
}



/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/
DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber to identify the drive */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Start sector in LBA */
	UINT count		/* Number of sectors to read */
)
{
	switch (pdrv) {
	case SD_TF :
		return (DRESULT)SD_ReadDisk(buff, sector, count);
	}

	return RES_PARERR;
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/

#if FF_FS_READONLY == 0

DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber to identify the drive */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Start sector in LBA */
	UINT count			/* Number of sectors to write */
)
{
	switch (pdrv) {
	case SD_TF :
		return (DRESULT)SD_WriteDisk((uint8_t *)buff, sector, count);
	}

	return RES_PARERR;
}

#endif


/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/
DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	u8 result = RES_OK;
    switch (pdrv)
    {
    case SD_TF :
        switch(cmd)
        {
        case CTRL_SYNC:
            SD_CS(0);
            if(SD_WaitReady())result = RES_ERROR;
            SD_CS(1);
            break;
        case GET_SECTOR_SIZE:
            *(WORD *)buff = 512;
            break;
        case GET_BLOCK_SIZE:
            *(WORD *)buff = 8;
            break;
        case GET_SECTOR_COUNT:
            *(DWORD *)buff = SD_GetSectorCount();
            break;
        default:
            result = RES_PARERR;
            break;
        }
        break;
    }
    if(!result)return RES_OK;

    return RES_PARERR;
}

DWORD get_fattime (void)
{
    u32 date;
    date =
        (
            ((2015 - 1980) << 25)  |
            (7 <<  21 ) |
            (9 <<  16 ) |
            (12 << 11 ) |
            ( 4 << 5  ) |
            ( 0 )
        );

    return date;
}

void *ff_memalloc (UINT msize)
{
    return malloc(msize);
}

void ff_memfree (void *mblock)		/* Free memory block */
{
    free(mblock);
}
