#ifndef _SHT20_H_
#define _SHT20_H_

#include "stm32f10x.h"
#include "delay.h"

#define SHT20OUT_SCL(x)  (x)?(GPIO_SetBits(GPIOB,GPIO_Pin_10)):(GPIO_ResetBits(GPIOB,GPIO_Pin_10))
#define SHT20OUT_SDA(x)  (x)?(GPIO_SetBits(GPIOB,GPIO_Pin_11)):(GPIO_ResetBits(GPIOB,GPIO_Pin_11)) 
#define SHT20IN_SDA   GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_11)  //����SDA 

#define SHT20SDA_IN		{GPIOB->CRH &= ~(0XF << 12);GPIOB->CRH |= (0X4 << 12);}
#define SHT20SDA_OUT 	{GPIOB->CRH &= ~(0XF << 12);GPIOB->CRH |= (0X7 << 12);}

#define SHT20_Adder 0x80 	//SHT20������ַ
#define CMD_Write  	0xE6 	//д����
#define CMD_Read   	0xE7 	//������
#define CMD_GetTem 	0xF3	//�����¶�����
#define CMD_GetHum 	0xF5  //�������ʪ������

typedef enum{
	IIC_ACK=0,
	IIC_NACK
}_IICack;

typedef struct{
	float Tem;
	float Hum;
}_SHT20Data;

void SHT20_Config(void);
void SHT20_GetData(_SHT20Data *data);

#endif

