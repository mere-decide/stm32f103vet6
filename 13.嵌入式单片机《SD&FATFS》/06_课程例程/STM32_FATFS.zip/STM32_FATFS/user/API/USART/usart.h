#ifndef _USART_H_
#define _USART_H_

#include "stm32f10x.h"
#include "stdio.h"

void USART_Config(void);

#endif


