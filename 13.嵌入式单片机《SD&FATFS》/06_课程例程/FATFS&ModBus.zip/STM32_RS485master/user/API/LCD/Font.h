#ifndef _FONT_H_
#define _FONT_H_

#include "stm32f10x.h"
#include "string.h"
#include "stdio.h"

//�ַ�ȡģ������PCtoLCD2002
//�ַ�ȡģ��ʽ�����롢���С�˳��C51
extern uint8_t ASCII_Font16Buf[];
extern uint8_t ASCII_Font24Buf[];
extern uint8_t ASCII_Font32Buf[];

extern uint8_t GB2312_Font16Buf[];
extern uint8_t GB2312_Font24Buf[];
extern uint8_t GB2312_Font32Buf[];

int ASCII_GetFontAddr(uint8_t Font);
int GB2312_GetFont16Addr(uint8_t Font1,uint8_t Font2);
int GB2312_GetFont24Addr(uint8_t Font1,uint8_t Font2);
int GB2312_GetFont32Addr(uint8_t Font1,uint8_t Font2);

#endif
