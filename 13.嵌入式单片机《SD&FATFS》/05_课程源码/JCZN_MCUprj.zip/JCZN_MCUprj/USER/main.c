#include "stm32f10x.h"
#include "led.h"
#include "delay.h"
#include "key.h"
#include "beep.h"
#include "exti.h"
#include "USART.h"
#include "basictim.h"
#include "timled.h"
#include "adc.h"
#include "dma.h"
#include "W25Qxx.h"
#include "sht20.h"
#include "st7789.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "event_groups.h"
#include "timers.h"
#include "modbus.h"
#include "mmc_sd.h"
#include "ff.h"

TaskHandle_t Handle_Create = NULL;
TaskHandle_t Handle_RS485 = NULL;
TaskHandle_t Handle_ModBus = NULL;

void Fanction_CreateTask(void *p);
void Fanction_RS485(void *p);
void Fanction_ModBus(void *p);

FATFS SD_Fatfs = {0};
FIL fp = {0};
UINT bw = 0;

int main(void)
{
	uint32_t FlashID = 0X0;
	uint8_t ReadBuf[32] = "\0";
	NVIC_SetPriorityGrouping(5);
//	LED_Config();
	BEEP_Config();
	KEY_Config();
	EXTI_Config();
	USART1_Config(9600);
//	SysTick_Config(72000);
	TIM6_Config();
	TIM4_Config();
//	LED2_Ctrl(1);
//	ADC2_Config();
	DMA1_Config();
	sFLASH_Config();
	SHT20_Config();
	LCD_Config();
	
	ST7789_ShowString(0,91,0X001F,0XFFFF,"֣��(Zhengzhou)������ܣ�JCZN��");
	
	uint8_t TestBuf[2] = {0XC9,0XA3};
	FlashID = sFLASH_ReadID();
	printf("USART&printf Test  %s\r\n",TestBuf);
	if(SD_Config() == 0)
	{
		printf("SD config OK\r\n");
		
		if(f_mount(&SD_Fatfs,"0:",0) == FR_OK)
		{
			if(f_open(&fp,"0:JC1019.txt",FA_OPEN_ALWAYS|FA_READ|FA_WRITE) == FR_OK)
			{
				f_write(&fp,"2023.07.17 Ϊ����Ϊ��",sizeof("2023.07.17 Ϊ����Ϊ��"),&bw);
				
				printf("FATFS OK\r\n");
				f_close(&fp);
			}
		}
		
	}
	else
		printf("SD config error\r\n");
	
	
	if((FlashID == sFLASH_W25Q16_ID)||(FlashID == sFLASH_W25Q32_ID))
	{
		printf("Falsh ID ��%x\r\n",FlashID);
		
		//д������
//		sFLASH_EraseSector(0X000100);
//		sFLASH_WriteBuffer("today is good!!",0X000110,sizeof("today is good!!"));
		sFLASH_ReadBuffer(ReadBuf,0X000110,15);
		printf("ReadBuf:***%s***\r\n",ReadBuf);
	}

	static char String[32] = "I am a test code!";
	
	if(xTaskCreate(Fanction_CreateTask,/*������--����ָ��*/
							"Task_Create",/*������--�ַ���*/
							256,/*�����ջ��С--����*/
							String,/*�����������β�--����ָ��*/
							1,/*���ȼ�--����*/
							&Handle_Create/*������--�ṹ��ָ���ָ��*/
	) == pdPASS)
		vTaskStartScheduler();
	else
		printf("FreeRTOS Start Fail ! Open Bare Metal System !\r\n");

	while(1)
	{	
	
	}
}

void Fanction_CreateTask(void *p)
{
	taskENTER_CRITICAL();

	xTaskCreate(Fanction_RS485,"Task_485",256,NULL,2,&Handle_RS485);
	xTaskCreate(Fanction_ModBus,"Task_ModBus",512,NULL,2,&Handle_ModBus);

	taskEXIT_CRITICAL();
	
	vTaskDelete(Handle_Create);
}

void Fanction_RS485(void *p)
{
	ModBus_Config(9600);

	
	while(1)
	{
		ModBus_Send03Cmd(66,1,2);
		
		vTaskDelay(1000);
	}
}

void Fanction_ModBus(void *p)
{
	uint8_t temp = 0;
	uint16_t GetCRC = 0,CountCRC = 0;
	while(1)
	{	
		if(RS485_GetData.Flag)
		{
			if(RS485_GetData.count >= 4)
			{
				//��λ�����ԡ���Ļ����
				printf("Get data:");
				for(temp=0;temp<RS485_GetData.count;temp++)
					printf("%#0x ",RS485_GetData.data[temp]);
				printf("\r\n");
				
				GetCRC = (RS485_GetData.data[RS485_GetData.count-2])|(RS485_GetData.data[RS485_GetData.count-1]<<8);
				CountCRC = ModBus_CRC16(RS485_GetData.data,RS485_GetData.count-2);
				if(GetCRC == CountCRC)
				{
					printf("У��ͨ��\r\n");
				}
			}
			
			RS485_GetData.Flag = 0;
			RS485_GetData.count = 0;
			memset(RS485_GetData.data,0,128);
		}
		vTaskDelay(10);
	}
}


