#ifndef _TIMLED_H_
#define _TIMLED_H_

#include "stm32f10x.h"

void TIM4_Config(void);

#endif


