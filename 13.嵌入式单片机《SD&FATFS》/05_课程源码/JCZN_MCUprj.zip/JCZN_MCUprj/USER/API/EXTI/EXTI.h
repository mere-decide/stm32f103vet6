#ifndef _EXTI_H_
#define _EXTI_H_

#include "stm32f10x.h"
#include "delay.h"
#include "stdio.h"

extern uint8_t State;

void EXTI_Config(void);

#endif
